<h4>Definition</h4>

<br>

<img src="specialty-rx-request-messagedefinition.png" alt="request-message-definition-content"/><br><br>