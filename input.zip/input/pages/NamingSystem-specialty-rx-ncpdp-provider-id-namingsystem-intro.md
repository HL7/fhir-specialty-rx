﻿This NamingSystem references the licensed NCPDP Provider ID identifier system maintained by the National Council for Prescription Drug Programs. Its full, up-to-date content is only available to licensees.

Below are fictional identifiers that reflect the NCPDP Provider ID structure, for illustration purposes. 

<table border="1">
<tr><td><b>ID (fictional)</b></td><td><b>Pharmacy Name (fictional)</b></td></tr>
<tr><td>0999017</td><td>Specialist Specialty Drug</td></tr>
<tr><td>0999029</td><td>AAA1 Specialty Pharmacy</td></tr>
<tr><td>0999031</td><td>Acme Specialty Pharmacy</td></tr>
<tr><td>0999043</td><td>Local Specialty Pharmacy</td></tr>
</table>


<br>