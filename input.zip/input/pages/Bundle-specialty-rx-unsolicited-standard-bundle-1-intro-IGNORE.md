<h4>Example description</h4>

This example illustrates an unsolicited Specialty Rx message containing information defined in a standard enrollment form.

It contains patient conditions, current medications, allergies and vitals.


<h4>Example data content</h4>

<br>

<img src="specialty-rx-unsolicited-standard-bundle-1.png" alt="example data content"/><br><br>