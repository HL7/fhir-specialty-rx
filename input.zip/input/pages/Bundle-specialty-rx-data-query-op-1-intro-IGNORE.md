<h4>Example data content</h4>
<br>

<img src="specialty-rx-data-query-1.png" alt="example data content"/><br><br>