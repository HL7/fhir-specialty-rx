<h4>Example data content</h4>
<br>

<img src="specialty-rx-lab-observation-1.png" alt="example data content"/><br><br>