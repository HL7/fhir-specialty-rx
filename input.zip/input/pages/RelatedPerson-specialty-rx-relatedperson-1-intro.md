<h4>Example data content</h4>
<br>

<img src="specialty-rx-relatedperson-1.png" alt="example data content"/><br><br>