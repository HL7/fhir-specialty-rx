<h4>Definition</h4>

<br>

<img src="specialty-rx-response-messagedefinition.png" alt="response-message-definition-content"/><br><br>